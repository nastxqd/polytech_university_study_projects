using System.IO;
using System.Text.Json;
using StudyPlanner.Models;

namespace StudyPlanner.Services;

public sealed class TaskStorage
{
    private readonly string _filePath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "StudyPlanner", "tasks.json");

    public List<StudyTask> Load()
    {
        try
        {
            if (File.Exists(_filePath))
            {
                var tasks = JsonSerializer.Deserialize<List<StudyTask>>(File.ReadAllText(_filePath));
                if (tasks is { Count: > 0 }) return tasks;
            }
        }
        catch (JsonException) { }

        return CreateDemoTasks();
    }

    public void Save(IEnumerable<StudyTask> tasks)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(_filePath)!);
        var json = JsonSerializer.Serialize(tasks, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(_filePath, json);
    }

    private static List<StudyTask> CreateDemoTasks() =>
    [
        new() { Title = "Подготовить вопросы к семинару", Subject = "Программирование", DueDate = DateTime.Today, Priority = TaskPriority.Высокий, EstimatedMinutes = 60 },
        new() { Title = "Повторить тему коллекций", Subject = "Программирование", DueDate = DateTime.Today.AddDays(1), Priority = TaskPriority.Средний, EstimatedMinutes = 45 },
        new() { Title = "Сдать лабораторную работу №2", Subject = "Базы данных", DueDate = DateTime.Today.AddDays(2), Priority = TaskPriority.Высокий, EstimatedMinutes = 90 },
        new() { Title = "Прочитать главу 4", Subject = "Английский язык", DueDate = DateTime.Today.AddDays(3), Priority = TaskPriority.Низкий, EstimatedMinutes = 30 },
        new() { Title = "Составить план курсового проекта", Subject = "Проектная деятельность", DueDate = DateTime.Today.AddDays(5), Priority = TaskPriority.Средний, EstimatedMinutes = 60 },
        new() { Title = "Загрузить отчёт в LMS", Subject = "Базы данных", DueDate = DateTime.Today.AddDays(-1), Priority = TaskPriority.Высокий, EstimatedMinutes = 15, IsCompleted = true }
    ];
}
