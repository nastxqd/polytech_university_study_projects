using System.Collections.ObjectModel;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using StudyPlanner.Models;
using StudyPlanner.Services;

namespace StudyPlanner;

public partial class MainWindow : Window
{
    private readonly TaskStorage _storage = new();
    private readonly ObservableCollection<StudyTask> _tasks = new();
    private readonly string[] _palette = ["#5B5CE2", "#22A06B", "#E58C33", "#D64C67", "#2F9BC5"];

    public MainWindow()
    {
        InitializeComponent();
        foreach (var task in _storage.Load()) _tasks.Add(task);
        DateLabel.Text = $"Сегодня, {DateTime.Today.ToString("d MMMM yyyy", new CultureInfo("ru-RU"))}";
        QuickDate.SelectedDate = DateTime.Today;
        RefreshAll();
    }

    private void RefreshAll()
    {
        var subjects = _tasks.Select(t => t.Subject).Distinct().OrderBy(s => s).ToList();
        QuickSubject.ItemsSource = subjects;
        if (QuickSubject.SelectedItem is null && subjects.Count > 0) QuickSubject.SelectedIndex = 0;
        BuildSubjectMenu(subjects);
        UpdateCards();
        BuildWeekStrip();
        BuildSubjectStats(subjects);
        BuildTaskList(_tasks.Where(t => !t.IsCompleted).OrderBy(t => t.DueDate).ThenByDescending(t => t.Priority).Take(5));
        FocusTip.Text = _tasks.Any(t => !t.IsCompleted && t.Priority == TaskPriority.Высокий) ? "Начните с задачи высокого приоритета" : "Все важные дела под контролем";
    }

    private void UpdateCards()
    {
        var week = _tasks.Where(t => t.DueDate.Date >= DateTime.Today.AddDays(-6) && t.DueDate.Date <= DateTime.Today.AddDays(7)).ToList();
        var completed = week.Count(t => t.IsCompleted);
        var percentage = week.Count == 0 ? 0 : (int)Math.Round(completed * 100d / week.Count);
        CompletedValue.Text = $"{percentage}%";
        CompletedHint.Text = $"{completed} из {week.Count} задач";
        var today = _tasks.Count(t => !t.IsCompleted && t.DueDate.Date == DateTime.Today);
        TodayValue.Text = today.ToString();
        TodayHint.Text = today == 0 ? "на сегодня всё чисто" : "задач требуют внимания";
        var minutes = week.Where(t => !t.IsCompleted).Sum(t => t.EstimatedMinutes);
        MinutesValue.Text = minutes >= 60 ? $"{minutes / 60d:0.#} ч" : $"{minutes} мин";
    }

    private void BuildSubjectMenu(List<string> subjects)
    {
        SubjectMenu.Items.Clear();
        for (var i = 0; i < subjects.Count; i++)
        {
            var button = new Button { Content = $"●   {subjects[i]}", Tag = subjects[i], Style = (Style)FindResource("NavButton") };
            button.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString(_palette[i % _palette.Length]));
            button.Click += Subject_Click;
            SubjectMenu.Items.Add(button);
        }
    }

    private void BuildWeekStrip()
    {
        WeekStrip.Items.Clear();
        var ru = new CultureInfo("ru-RU");
        for (var i = 0; i < 7; i++)
        {
            var day = DateTime.Today.AddDays(i);
            var count = _tasks.Count(t => !t.IsCompleted && t.DueDate.Date == day.Date);
            var stack = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center };
            stack.Children.Add(new TextBlock { Text = day.ToString("ddd", ru).ToUpperInvariant(), FontSize = 10, Foreground = (Brush)FindResource("TextSecondary"), HorizontalAlignment = HorizontalAlignment.Center });
            stack.Children.Add(new TextBlock { Text = day.Day.ToString(), FontSize = 19, FontWeight = FontWeights.SemiBold, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 5, 0, 8) });
            var bar = new Border { Height = Math.Min(48, 10 + count * 11), Width = 24, CornerRadius = new CornerRadius(6), Background = count == 0 ? (Brush)FindResource("LineColor") : (Brush)FindResource("Accent"), VerticalAlignment = VerticalAlignment.Bottom };
            stack.Children.Add(bar);
            WeekStrip.Items.Add(new Border { Child = stack, Padding = new Thickness(5, 0, 5, 0), ToolTip = $"{day:d}: {count} задач" });
        }
    }

    private void BuildSubjectStats(List<string> subjects)
    {
        SubjectStats.Items.Clear();
        foreach (var subject in subjects)
        {
            var count = _tasks.Count(t => !t.IsCompleted && t.Subject == subject);
            var row = new Grid { Margin = new Thickness(0, 0, 0, 12) };
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            row.Children.Add(new TextBlock { Text = subject, FontSize = 12, Foreground = (Brush)FindResource("TextPrimary") });
            var value = new TextBlock { Text = count.ToString(), FontSize = 12, FontWeight = FontWeights.SemiBold, Foreground = (Brush)FindResource("Accent") };
            Grid.SetColumn(value, 1); row.Children.Add(value);
            SubjectStats.Items.Add(row);
        }
    }

    private void BuildTaskList(IEnumerable<StudyTask> source)
    {
        TaskList.Items.Clear();
        foreach (var task in source)
        {
            var grid = new Grid { Margin = new Thickness(0, 0, 0, 10) };
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var done = new CheckBox { IsChecked = task.IsCompleted, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0, 2, 10, 0), Tag = task };
            done.Checked += TaskToggle; done.Unchecked += TaskToggle; grid.Children.Add(done);
            var text = new StackPanel();
            text.Children.Add(new TextBlock { Text = task.Title, FontSize = 13, FontWeight = FontWeights.SemiBold });
            text.Children.Add(new TextBlock { Text = $"{task.Subject}  •  {task.DateText}  •  {task.EstimatedMinutes} мин", FontSize = 11, Foreground = (Brush)FindResource("TextSecondary"), Margin = new Thickness(0, 3, 0, 0) });
            Grid.SetColumn(text, 1); grid.Children.Add(text);
            var priority = new Border { CornerRadius = new CornerRadius(6), Padding = new Thickness(7, 3, 7, 3), Background = PriorityBrush(task.Priority), Child = new TextBlock { Text = task.Priority.ToString(), FontSize = 10, Foreground = PriorityTextBrush(task.Priority) } };
            Grid.SetColumn(priority, 2); grid.Children.Add(priority);
            TaskList.Items.Add(grid);
        }
        if (TaskList.Items.Count == 0) TaskList.Items.Add(new TextBlock { Text = "Все задачи выполнены — отличный результат!", Foreground = (Brush)FindResource("Green"), Margin = new Thickness(0, 8, 0, 8) });
    }

    private Brush PriorityBrush(TaskPriority priority) => new SolidColorBrush((Color)ColorConverter.ConvertFromString(priority switch { TaskPriority.Высокий => "#FDE9EE", TaskPriority.Средний => "#FFF1E1", _ => "#E5F7EF" }));
    private Brush PriorityTextBrush(TaskPriority priority) => new SolidColorBrush((Color)ColorConverter.ConvertFromString(priority switch { TaskPriority.Высокий => "#D64C67", TaskPriority.Средний => "#C87820", _ => "#188758" }));

    private void TaskToggle(object sender, RoutedEventArgs e)
    {
        if (sender is CheckBox { Tag: StudyTask task } check) { task.IsCompleted = check.IsChecked == true; _storage.Save(_tasks); RefreshAll(); }
    }

    private void QuickAdd_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(QuickTitle.Text)) { MessageBox.Show("Введите название задачи.", "Не хватает данных", MessageBoxButton.OK, MessageBoxImage.Information); return; }
        _tasks.Add(new StudyTask { Title = QuickTitle.Text.Trim(), Subject = QuickSubject.SelectedItem?.ToString() ?? "Общее", DueDate = QuickDate.SelectedDate ?? DateTime.Today, Priority = TaskPriority.Средний, EstimatedMinutes = 30 });
        _storage.Save(_tasks); QuickTitle.Clear(); RefreshAll();
    }

    private void AddTask_Click(object sender, RoutedEventArgs e) => QuickTitle.Focus();
    private void Overview_Click(object sender, RoutedEventArgs e) { RefreshAll(); }
    private void Tasks_Click(object sender, RoutedEventArgs e) => MessageBox.Show("Раздел списка задач уже доступен на главном экране. Используйте фильтры предметов слева или добавляйте задачи через форму.", "Все задачи", MessageBoxButton.OK, MessageBoxImage.Information);
    private void Week_Click(object sender, RoutedEventArgs e) => MessageBox.Show("На графике «Нагрузка по дням» показаны ближайшие 7 дней. Высота столбца зависит от числа незавершённых задач.", "Неделя", MessageBoxButton.OK, MessageBoxImage.Information);
    private void Analytics_Click(object sender, RoutedEventArgs e) => MessageBox.Show($"Всего задач: {_tasks.Count}\nВыполнено: {_tasks.Count(t => t.IsCompleted)}\nСредняя оценка времени: {(_tasks.Count == 0 ? 0 : _tasks.Average(t => t.EstimatedMinutes)):0} мин", "Аналитика", MessageBoxButton.OK, MessageBoxImage.Information);
    private void Subject_Click(object sender, RoutedEventArgs e) { if (sender is Button { Tag: string subject }) BuildTaskList(_tasks.Where(t => !t.IsCompleted && t.Subject == subject).OrderBy(t => t.DueDate)); }
}
