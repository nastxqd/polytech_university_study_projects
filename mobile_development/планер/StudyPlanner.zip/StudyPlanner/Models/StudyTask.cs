using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace StudyPlanner.Models;

public enum TaskPriority
{
    Низкий,
    Средний,
    Высокий
}

public sealed class StudyTask : INotifyPropertyChanged
{
    private bool _isCompleted;

    public Guid Id { get; set; } = Guid.NewGuid();
    public string Title { get; set; } = "Новая задача";
    public string Subject { get; set; } = "Общее";
    public DateTime DueDate { get; set; } = DateTime.Today;
    public TaskPriority Priority { get; set; } = TaskPriority.Средний;
    public int EstimatedMinutes { get; set; } = 30;
    public string Notes { get; set; } = "";

    public bool IsCompleted
    {
        get => _isCompleted;
        set
        {
            if (_isCompleted == value) return;
            _isCompleted = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(StatusText));
        }
    }

    public string StatusText => IsCompleted ? "Готово" : DueDate.Date < DateTime.Today ? "Просрочено" : "Запланировано";
    public string DateText => DueDate.Date == DateTime.Today ? "Сегодня" : DueDate.ToString("dd MMMM", new System.Globalization.CultureInfo("ru-RU"));

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string? propertyName = null) => PropertyChanged?.Invoke(this, new(propertyName));
}
