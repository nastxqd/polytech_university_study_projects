using FractionTrainer.Core.Enums;
using FractionTrainer.Core.Services;
using Xunit;

namespace FractionTrainer.Tests;

public class GeneratorRegressionTests
{
    [Theory]
    [InlineData(DifficultyLevel.Easy)]
    [InlineData(DifficultyLevel.Medium)]
    [InlineData(DifficultyLevel.Hard)]
    public void PairsBoard_CanBeCompletelyMatched(DifficultyLevel level)
    {
        var generator = new PuzzleGenerator();
        for (int iteration = 0; iteration < 200; iteration++)
        {
            var puzzle = generator.GenerateFindPairs(level);
            Assert.Equal(6, puzzle.Cards.Count);
            var groups = puzzle.Cards.GroupBy(c => c.Fraction.Simplify()).ToList();
            Assert.Equal(3, groups.Count);
            Assert.All(groups, group => Assert.Equal(2, group.Count()));
            Assert.True(puzzle.CorrectPair.FractionA.IsEquivalentTo(puzzle.CorrectPair.FractionB));
            Assert.All(puzzle.Cards, card => Assert.InRange(card.HighlightedSectors, 1, card.TotalSectors - 1));
        }
    }

    [Theory]
    [InlineData(DifficultyLevel.Easy)]
    [InlineData(DifficultyLevel.Medium)]
    [InlineData(DifficultyLevel.Hard)]
    public void EquivalentOptions_HaveExactlyOneCorrectAnswer(DifficultyLevel level)
    {
        var generator = new PuzzleGenerator();
        for (int iteration = 0; iteration < 200; iteration++)
        {
            var puzzle = generator.GenerateEquivalent(level);
            Assert.Equal(4, puzzle.Options.Count);
            Assert.Single(puzzle.Options, option => option.IsEquivalentTo(puzzle.TargetFraction));
            Assert.Equal(4, puzzle.Options.Select(option => option.Simplify()).Distinct().Count());
        }
    }
}
