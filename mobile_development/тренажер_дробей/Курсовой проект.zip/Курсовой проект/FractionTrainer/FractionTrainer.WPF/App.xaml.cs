using System.Windows;
using System.Windows.Media;
using FractionTrainer.Core.Services;

namespace FractionTrainer.WPF
{
    /// <summary>
    /// Точка входа приложения WPF.
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            var settings = new SettingsService().Load();
            ApplyAppearance(settings.Theme, settings.AccentColor);
            base.OnStartup(e);
        }

        public static void ApplyAppearance(string themeName, string accentColor)
        {
            SwitchTheme(themeName);
            if (ColorConverter.ConvertFromString(accentColor) is Color color)
            {
                Application.Current.Resources["AccentColor"] = new SolidColorBrush(color);
                double luminance = 0.2126 * color.R + 0.7152 * color.G + 0.0722 * color.B;
                Application.Current.Resources["AccentForeground"] =
                    luminance > 160 ? Brushes.Black : Brushes.White;
            }
        }
        /// <summary>
        /// Переключает тему приложения.
        /// </summary>
        /// <param name="themeName">Имя темы: "Light" или "Dark".</param>
        public static void SwitchTheme(string themeName)
        {
            Application currentApp = Application.Current;
            ResourceDictionary? oldTheme = currentApp.Resources.MergedDictionaries
                .OfType<ResourceDictionary>()
                .FirstOrDefault(d => d.Source?.OriginalString.Contains("Theme") == true);

            if (oldTheme != null)
            {
                currentApp.Resources.MergedDictionaries.Remove(oldTheme);
            }

            string themePath = themeName == "Dark"
                ? "Themes/DarkTheme.xaml"
                : "Themes/LightTheme.xaml";

            ResourceDictionary newTheme = new ResourceDictionary
            {
                Source = new Uri($"pack://application:,,,/FractionTrainer.WPF;component/{themePath}", UriKind.Absolute)
            };

            currentApp.Resources.MergedDictionaries.Add(newTheme);
        }
    }
}
