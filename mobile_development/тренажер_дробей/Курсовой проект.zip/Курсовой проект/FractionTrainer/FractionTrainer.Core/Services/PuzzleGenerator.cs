using FractionTrainer.Core.Enums;
using FractionTrainer.Core.Interfaces;
using FractionTrainer.Core.Models;

namespace FractionTrainer.Core.Services
{
    public class PuzzleGenerator : IPuzzleGenerator
    {
        private readonly Random _random = new Random();

        private int[] GetDenominators(DifficultyLevel difficulty)
        {
            return difficulty switch
            {
                DifficultyLevel.Easy => new[] { 2, 3, 4 },
                DifficultyLevel.Medium => new[] { 2, 3, 4, 5, 6 },
                DifficultyLevel.Hard => new[] { 2, 3, 4, 5, 6, 8, 10 },
                _ => throw new ArgumentOutOfRangeException(nameof(difficulty))
            };
        }

        private Fraction GenerateRandomFraction(DifficultyLevel difficulty)
        {
            int[] denominators = GetDenominators(difficulty);
            int denominator = denominators[_random.Next(denominators.Length)];
            int numerator = _random.Next(1, denominator);
            return new Fraction(numerator, denominator);
        }

        public FractionPuzzle Generate(DifficultyLevel difficulty)
        {
            return GenerateWithType(difficulty, PuzzleType.BuildFraction);
        }

        public FractionPuzzle GenerateWithType(DifficultyLevel difficulty, PuzzleType type)
        {
            Fraction fraction = GenerateRandomFraction(difficulty);
            ShapeType shape = (ShapeType)_random.Next(Enum.GetValues(typeof(ShapeType)).Length);
            var puzzle = new FractionPuzzle(fraction, type) { Shape = shape };
            return puzzle;
        }

        public ComparePuzzle GenerateCompare(DifficultyLevel difficulty)
        {
            Fraction a = GenerateRandomFraction(difficulty);
            Fraction b;
            do
            {
                b = GenerateRandomFraction(difficulty);
            }
            while (a.IsEquivalentTo(b));

            return new ComparePuzzle(a, b);
        }

        public CompleteToWholePuzzle GenerateCompleteToWhole(DifficultyLevel difficulty)
        {
            Fraction fraction = GenerateRandomFraction(difficulty);
            return new CompleteToWholePuzzle(fraction);
        }

        public EquivalentPuzzle GenerateEquivalent(DifficultyLevel difficulty)
        {
            int[] denominators = GetDenominators(difficulty);
            int targetDenom = denominators[_random.Next(denominators.Length)];
            int targetNum = _random.Next(1, targetDenom);

            Fraction target = new Fraction(targetNum, targetDenom);
            Fraction simplified = target.Simplify();

            List<Fraction> options = new List<Fraction>();
            options.Add(simplified);

            int attempts = 0;
            while (options.Count < 4 && attempts < 50)
            {
                attempts++;
                int optDenom = denominators[_random.Next(denominators.Length)];
                int optNum = _random.Next(1, optDenom);
                Fraction opt = new Fraction(optNum, optDenom);

                bool isDuplicate = options.Any(o => o.IsEquivalentTo(opt));
                bool isSame = opt.IsEquivalentTo(target);

                if (!isDuplicate && !isSame)
                {
                    options.Add(opt);
                }
            }

            while (options.Count < 4)
            {
                int fallbackDenom = denominators[_random.Next(denominators.Length)];
                int fallbackNum = _random.Next(1, fallbackDenom);
                Fraction fallback = new Fraction(fallbackNum, fallbackDenom);
                if (!options.Any(o => o.IsEquivalentTo(fallback)))
                {
                    options.Add(fallback);
                }
            }

            options = options.OrderBy(_ => _random.Next()).ToList();

            return new EquivalentPuzzle(target, simplified, options);
        }

        public FindPairsPuzzle GenerateFindPairs(DifficultyLevel difficulty)
        {
            int[] denominators = GetDenominators(difficulty);
            ShapeType[] shapes = Enum.GetValues<ShapeType>();
            // Группируем все допустимые записи по точному значению дроби.
            var groups = denominators
                .SelectMany(den => Enumerable.Range(1, den - 1).Select(num => new Fraction(num, den)))
                .GroupBy(fraction => fraction.Simplify())
                .OrderBy(_ => _random.Next())
                .Take(3);
            var cards = new List<PairCard>();
            FractionPair? hintPair = null;
            foreach (var group in groups)
            {
                var representations = group.OrderBy(_ => _random.Next()).ToList();
                Fraction first = representations[0];
                Fraction second = representations.Count > 1 ? representations[1] : first;
                int shapeIndex = _random.Next(shapes.Length);
                cards.Add(new PairCard(first, shapes[shapeIndex]));
                cards.Add(new PairCard(second, shapes[(shapeIndex + _random.Next(1, shapes.Length)) % shapes.Length]));
                hintPair ??= new FractionPair(first, second);
            }
            cards = cards.OrderBy(_ => _random.Next()).ToList();
            return new FindPairsPuzzle(cards, hintPair!);
        }
    }
}
