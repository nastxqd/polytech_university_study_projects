using System.Globalization;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Interop;
using FractionTrainer.Core.Enums;
using FractionTrainer.Core.Interfaces;
using FractionTrainer.Core.Models;
using FractionTrainer.Core.Services;
using FractionTrainer.WPF;
using FractionTrainer.WPF.Views;

internal class Program
{
    static readonly List<string> Results = new();
    static string output = "";
    static Window? host;
    [STAThread]
    static int Main(string[] args)
    {
        output = Path.GetFullPath(args[0]);
        Directory.CreateDirectory(Path.Combine(output, "screens"));
        var app = new App();
        app.InitializeComponent();
        host = new Window { Width = 1100, Height = 720, Left = -30000, Top = -30000, WindowStyle = WindowStyle.None, ShowInTaskbar = false, ShowActivated = false };
        host.Show();
        var settings = new SettingsService(Path.Combine(output, "smoke_settings.json"));
        settings.Save(AppSettings.CreateDefault());
        var settingsVm = new SettingsViewModel(settings);
        var settingsView = new SettingsView { DataContext = settingsVm };
        Layout(settingsView);
        var buttons = Descendants(settingsView).OfType<RadioButton>().ToList();
        var darkButton = buttons.Single(b => Equals(b.Content, "Тёмная"));
        darkButton.IsChecked = true;
        Layout(settingsView);
        Check("Dark radio selection survives Light uncheck", settingsVm.SelectedTheme == "Dark");
        Check("Dark background applied immediately", BrushColor("AppBackground") == (Color)ColorConverter.ConvertFromString("#16161E"));
        Check("Displayed view responds to theme change", ((SolidColorBrush)settingsView.Background).Color == BrushColor("AppBackground"));
        settingsVm.ExecuteSelectColor("#2ECC71");
        Check("Accent applied immediately", BrushColor("AccentColor") == (Color)ColorConverter.ConvertFromString("#2ECC71"));
        Render(settingsView, "settings_dark");
        settingsVm.ExecuteSave();
        var saved = new SettingsService(Path.Combine(output, "smoke_settings.json")).Load();
        Check("Theme and accent persist in JSON", saved.Theme == "Dark" && saved.AccentColor == "#2ECC71");
        App.ApplyAppearance(saved.Theme, saved.AccentColor);
        Check("Reapplying saved appearance preserves accent", BrushColor("AccentColor") == (Color)ColorConverter.ConvertFromString("#2ECC71"));
        var converter = new ThemeToBoolConverter();
        Check("Unchecked theme does not overwrite source", ReferenceEquals(converter.ConvertBack(false, typeof(string), "Dark", CultureInfo.InvariantCulture), Binding.DoNothing));
        var modeConverter = new AppModeToBoolConverter();
        Check("Unchecked mode does not overwrite source", ReferenceEquals(modeConverter.ConvertBack(false, typeof(AppMode), "Quiz", CultureInfo.InvariantCulture), Binding.DoNothing));
        settingsVm.SelectedDifficulty = DifficultyLevel.Hard;
        Layout(settingsView);
        Check("Difficulty control displays model value", Descendants(settingsView).OfType<ComboBox>().Single().SelectedIndex == 2);
        settingsVm.ExecuteReset();
        Check("Reset restores default appearance", settingsVm.SelectedTheme == "Light" && BrushColor("AccentColor") == (Color)ColorConverter.ConvertFromString("#4A90D9"));
        Render(settingsView, "settings_light");

        var trainer = new TrainerViewModel(new PuzzleGenerator(), settings);
        var view = new TrainerView { DataContext = trainer };
        trainer.SelectedMode = AppMode.Quiz;
        Check("Quiz hides answer and shows check", !trainer.IsShowAnswerVisible && trainer.IsCheckVisible);
        trainer.SelectedMode = AppMode.Learning;
        Check("Learning shows answer and hides check", trainer.IsShowAnswerVisible && !trainer.IsCheckVisible);
        foreach (PuzzleType type in Enum.GetValues<PuzzleType>())
        {
            Force(trainer, type);
            if (trainer.ShowShapeCanvas) trainer.CurrentShape = ShapeType.Circle;
            if (type == PuzzleType.BuildFraction)
            {
                trainer.ExecuteShowAnswer();
                int filled = trainer.SelectedSectors.Count;
                trainer.ExecuteToggleSector(0);
                Check("Answer reveal keeps model synchronized for next click", trainer.SelectedSectors.Count == filled - 1);
                trainer.ExecuteShowAnswer();
            }
            Render(view, type.ToString());
            if (type == PuzzleType.CompleteToWhole)
            {
                var circle = Descendants(view).OfType<FractionCircleControl>().Single();
                int painted = Descendants(circle).OfType<System.Windows.Shapes.Path>()
                    .Count(path => path.Fill is SolidColorBrush brush && brush.Color == trainer.SelectedSectorColor);
                Check("Complete-to-whole renders its highlighted sectors", painted == trainer.SelectedSectors.Count && painted > 0);
            }
            trainer.ExecuteReset();
            Check($"Reset preserves answer controls for {type}", type switch
            {
                PuzzleType.BuildFraction => trainer.ShowShapeCanvas && trainer.SelectedSectors.Count == 0,
                PuzzleType.IdentifyFraction => trainer.ShowShapeCanvas && trainer.ShowFractionInput,
                PuzzleType.CompareFractions => !trainer.ShowShapeCanvas && trainer.ShowCompareOptions,
                PuzzleType.CompleteToWhole => trainer.ShowShapeCanvas && trainer.ShowCompleteToWhole,
                PuzzleType.FindEquivalent => !trainer.ShowShapeCanvas && trainer.ShowEquivalentOptions,
                _ => !trainer.ShowShapeCanvas && trainer.ShowPairsBoard
            });
            if (type == PuzzleType.FindPairs)
            {
                var scoreBefore = trainer.ScoreText;
                trainer.ExecuteCheckAnswer();
                Check("Check does not record a false failure in pairs mode", trainer.ScoreText == scoreBefore);
                while (trainer.PairCards.Any(c => !c.IsMatched))
                {
                    int i = trainer.PairCards.FindIndex(c => !c.IsMatched);
                    int j = trainer.PairCards.FindIndex(c => !c.IsMatched && !ReferenceEquals(c, trainer.PairCards[i]) && c.Fraction.IsEquivalentTo(trainer.PairCards[i].Fraction));
                    Check("An unmatched pair exists", j >= 0);
                    trainer.ExecuteSelectPairCard(i); trainer.ExecuteSelectPairCard(j);
                }
                Check("Pairs game reaches completion", trainer.FeedbackText == "Все пары найдены!");
            }
            else
            {
                trainer.ExecuteCheckAnswer();
                Check($"Empty answer rejected for {type}", !trainer.ShowCheckmark);
                PrepareCorrect(trainer, type);
                trainer.ExecuteCheckAnswer();
                Check($"Correct answer accepted for {type}", trainer.ShowCheckmark);
            }
        }
        Force(trainer, PuzzleType.IdentifyFraction);
        trainer.UserNumeratorInput = "abc"; trainer.UserDenominatorInput = "0";
        trainer.ExecuteCheckAnswer();
        Check("Invalid fraction input does not crash", !trainer.ShowCheckmark);
        settings.Save(new AppSettings { AccentColor = "#E74C3C" });
        trainer.RefreshAccentColor();
        Check("Trainer reloads saved sector color", trainer.SelectedSectorColor == (Color)ColorConverter.ConvertFromString("#E74C3C"));
        var repo = new JsonScoreRepository(Path.Combine(output, "smoke_scores.json"));
        var session = new PuzzleSession(AppMode.Quiz);
        var attempt = session.StartAttempt(new FractionPuzzle(new Fraction(1, 2)));
        session.FinishAttempt(attempt, true);
        repo.Save(session.GetResult());
        var stored = repo.LoadAll().Last();
        Check("Session result round trips through JSON", stored.CorrectAnswers == 1 && stored.AccuracyPercent == 100);
        File.WriteAllLines(Path.Combine(output, "smoke_results.txt"), Results);
        Console.WriteLine($"PASS {Results.Count} checks");
        return 0;
    }
    static void Check(string name, bool ok)
    {
        if (!ok) throw new Exception("FAIL: " + name);
        Results.Add("PASS " + name);
    }
    static Color BrushColor(string key) => ((SolidColorBrush)Application.Current.FindResource(key)).Color;
    static object Field(TrainerViewModel vm, string name) => typeof(TrainerViewModel).GetField(name, BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(vm)!;
    static void Force(TrainerViewModel vm, PuzzleType type)
    {
        typeof(TrainerViewModel).GetMethod("ResetInputState", BindingFlags.NonPublic | BindingFlags.Instance)!.Invoke(vm, null);
        typeof(TrainerViewModel).GetField("_currentPuzzleType", BindingFlags.NonPublic | BindingFlags.Instance)!.SetValue(vm, type);
        string method = type switch { PuzzleType.BuildFraction => "GenerateBuildFraction", PuzzleType.IdentifyFraction => "GenerateIdentifyFraction", PuzzleType.CompareFractions => "GenerateCompareFractions", PuzzleType.CompleteToWhole => "GenerateCompleteToWhole", PuzzleType.FindEquivalent => "GenerateFindEquivalent", _ => "GenerateFindPairs" };
        typeof(TrainerViewModel).GetMethod(method, BindingFlags.NonPublic | BindingFlags.Instance)!.Invoke(vm, null);
    }
    static void PrepareCorrect(TrainerViewModel vm, PuzzleType type)
    {
        switch (type)
        {
            case PuzzleType.BuildFraction: vm.ExecuteShowAnswer(); break;
            case PuzzleType.IdentifyFraction:
                var puzzle = (FractionPuzzle)Field(vm, "_currentPuzzle");
                vm.UserNumeratorInput = (puzzle.TargetFraction.Numerator * 2).ToString();
                vm.UserDenominatorInput = (puzzle.TargetFraction.Denominator * 2).ToString(); break;
            case PuzzleType.CompareFractions:
                var compare = (ComparePuzzle)Field(vm, "_currentComparePuzzle");
                vm.SelectedCompareIndex = compare.FractionA.IsEquivalentTo(compare.LargerFraction) ? 0 : 1; break;
            case PuzzleType.CompleteToWhole:
                vm.CompleteToWholeInput = ((CompleteToWholePuzzle)Field(vm, "_currentCompletePuzzle")).NeededFraction.Numerator.ToString(); break;
            case PuzzleType.FindEquivalent:
                var equivalent = (EquivalentPuzzle)Field(vm, "_currentEquivalentPuzzle");
                vm.SelectedEquivalentIndex = equivalent.Options.FindIndex(f => f.IsEquivalentTo(equivalent.TargetFraction)); break;
        }
    }
    static IEnumerable<DependencyObject> Descendants(DependencyObject root)
    {
        for (int i = 0; i < VisualTreeHelper.GetChildrenCount(root); i++)
        {
            var child = VisualTreeHelper.GetChild(root, i); yield return child;
            foreach (var next in Descendants(child)) yield return next;
        }
    }
    static void Layout(FrameworkElement view)
    {
        if (host!.Content != view) host.Content = view;
        System.Windows.Threading.Dispatcher.CurrentDispatcher.Invoke(() => { }, System.Windows.Threading.DispatcherPriority.ApplicationIdle);
        view.Measure(new Size(1100, 720)); view.Arrange(new Rect(0, 0, 1100, 720)); view.UpdateLayout();
    }
    static void Render(FrameworkElement view, string name)
    {
        Layout(view);
        var target = new RenderTargetBitmap(1100, 720, 96, 96, PixelFormats.Pbgra32);
        target.Render(view);
        var encoder = new PngBitmapEncoder(); encoder.Frames.Add(BitmapFrame.Create(target));
        using var file = File.Create(Path.Combine(output, "screens", name + ".png")); encoder.Save(file);
    }
}
